# Scientific Computing and Python for Data Science
**********************************************************

This repo contains all the projects, assignments and the notes that I have completed as a part of the course. The course covers all in Scientific Computing and Python for Data Science.


**The solutions have been uploaded for personal academic purposes and can be used as a reference by others (but I strongly recommend trying out the assignments on your own)**

Offered by: [Worldquant University](https://wqu-apply.thedataincubator.com/)

Language: Python

## Certificate:  [Verified by Worldquant University ](https://www.credly.com/badges/aaf44169-191b-4290-b65a-681341b712aa/public_url)


**Just for reference and I hope you can star⭐ me.**
  
## Contact me

  Gmail: dkarigwa@gmail.com
  
  LinkedIn: [MyLinkedIn](https://www.linkedin.com/in/dennis-karigwa)
